1. Simply run the "python3 script.py" on terminal. Ensure python 3 is present.
2. It will ask for which part you need plot by "Enter the part". Enter 1 or 2 as required.
3. Next it will ask for condition on sigmas by "Sigma - 'same'or 'different'". Enter same or different as required.
4. Plot will get open itself in default image viewer.